package com.proj2.models;

public class MyConstants {
	    public static final String SITE_KEY ="6LfcNCEUAAAAAInMi5-aLmz_8rhZ7cySFrOAemQB";

	    public static final String SECRET_KEY ="6LfcNCEUAAAAABaAk6ca1aXLwJrrNVW8ASKj7ROG";
}
