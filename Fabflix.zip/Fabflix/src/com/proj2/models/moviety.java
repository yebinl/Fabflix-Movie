package com.proj2.models;

public class moviety {

	private String movietitle;
	private int movieyear;
	private int movieid;
	private String banner;
	
	public String getBanner() {
		return banner;
	}
	public void setBanner(String banner) {
		this.banner = banner;
	}
	public int getMovieid() {
		return movieid;
	}
	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}
	public String getMovietitle() {
		return movietitle;
	}
	public void setMovietitle(String movietitle) {
		this.movietitle = movietitle;
	}
	public int getMovieyear() {
		return movieyear;
	}
	public void setMovieyear(int movieyear) {
		this.movieyear = movieyear;
	}
	
}
