package com.proj2.models;

public class androidData {
	private int movieid;
	private String title;
	private String banner_url;
	
	public int getMovieid() {
		return movieid;
	}
	
	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getBanner_url() {
		return banner_url;
	}
	
	public void setBanner_url(String banner_url) {
		this.banner_url = banner_url;
	}
}
